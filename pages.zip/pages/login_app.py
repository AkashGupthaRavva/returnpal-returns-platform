import streamlit as st
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from firebase_auth import auth

st.set_page_config(page_title="Login & Signup", layout="centered")
st.title("🔐 Seller Access Portal")

# --- Session Init ---
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

# --- Tabs for Login & Signup ---
tab1, tab2 = st.tabs(["🔑 Login", "🆕 Sign Up"])

# --- Login Tab ---
with tab1:
    st.subheader("Login to your account")
    with st.form("login_form"):
        login_email = st.text_input("Email")
        login_password = st.text_input("Password", type="password")
        login_submit = st.form_submit_button("Login")

        if login_submit:
            try:
                user = auth.sign_in_with_email_and_password(login_email, login_password)
                st.session_state.logged_in = True
                st.session_state.email = login_email
                st.success("✅ Login successful! Redirecting...")
                st.switch_page("seller_dashboard_app")
            except Exception as e:
                st.error("❌ Invalid email or password. Please try again.")

# --- Signup Tab ---
with tab2:
    st.subheader("Create a new seller account")
    with st.form("signup_form"):
        signup_email = st.text_input("Email", key="signup_email")
        signup_password = st.text_input("Password (min 6 chars)", type="password", key="signup_password")
        confirm_password = st.text_input("Confirm Password", type="password", key="confirm_password")
        signup_submit = st.form_submit_button("Sign Up")

        if signup_submit:
            if len(signup_password) < 6:
                st.warning("⚠️ Password must be at least 6 characters long.")
            elif signup_password != confirm_password:
                st.error("❌ Passwords do not match.")
            else:
                try:
                    auth.create_user_with_email_and_password(signup_email, signup_password)
                    st.success("✅ Account created successfully! Please log in.")
                except Exception as e:
                    st.error("❌ Error creating account. Email may already be in use.")

# --- Already Logged In ---
if st.session_state.logged_in:
    st.success(f"You are already logged in as {st.session_state.email}")
    if st.button("Go to Dashboard"):
        st.switch_page("seller_dashboard_app")