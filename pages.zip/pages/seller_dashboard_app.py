import streamlit as st
import requests
from datetime import datetime
from role_utils import get_user_role

# --- Config ---
st.set_page_config(page_title="Returns SaaS - Seller Dashboard", layout="wide")

# --- Auth ---
st.title("🔐 Seller Dashboard Login")
email = st.text_input("Enter your email")
if not email:
    st.stop()

role = get_user_role(email)
if role != "seller":
    if role == "admin":
        st.warning("⚠️ This is the seller dashboard. Please use the Admin Dashboard.")
    elif role == "unauthorized":
        st.info("Don't have access yet? Fill the form below to request seller access.")

        with st.form("request_access"):
            st.subheader("📝 Request Seller Access")
            full_name = st.text_input("Full Name")
            store_name = st.text_input("Store Name")
            request_email = st.text_input("Your Email", value=email)
            submitted = st.form_submit_button("Submit Request")

            if submitted:
                request_data = {
                    "fields": {
                        "full_name": {"stringValue": full_name},
                        "store_name": {"stringValue": store_name},
                        "email": {"stringValue": request_email},
                        "timestamp": {"timestampValue": datetime.utcnow().isoformat("T") + "Z"}
                    }
                }
                url = f"https://firestore.googleapis.com/v1/projects/returnssaas/databases/(default)/documents/pending_sellers?key=AIzaSyBaMcUWcLWfyYwIYXRmaeZhBKZCK-rJHSo"
                r = requests.post(url, json=request_data)
                if r.status_code == 200:
                    st.success("✅ Your request has been submitted. We will review and get back to you.")
                else:
                    st.error("❌ Failed to submit request. Please try again later.")
        st.stop()
    else:
        st.error("❌ You are not authorized to access this page.")
    st.stop()

# --- Firebase Setup ---
st.title("📦 Seller Return Dashboard")
API_KEY = "AIzaSyBaMcUWcLWfyYwIYXRmaeZhBKZCK-rJHSo"
PROJECT_ID = "returnssaas"
BASE_URL = f"https://firestore.googleapis.com/v1/projects/{PROJECT_ID}/databases/(default)/documents/return_requests?key={API_KEY}"

# --- Load Seller Data ---
def fetch_requests_for_store(store_name):
    response = requests.get(BASE_URL)
    if response.status_code != 200:
        return []

    docs = response.json().get("documents", [])
    records = []
    for doc in docs:
        fields = doc.get("fields", {})
        if fields.get("store_name", {}).get("stringValue", "").lower() == store_name.lower():
            records.append({
                "order_id": fields.get("order_id", {}).get("stringValue", "N/A"),
                "status": fields.get("status", {}).get("stringValue", "Pending"),
                "reason": fields.get("return_reason", {}).get("stringValue", "N/A"),
                "timestamp": fields.get("timestamp", {}).get("timestampValue", "")[:10],
            })
    return records

store_name = st.text_input("Enter your store name")
if not store_name:
    st.stop()

requests_data = fetch_requests_for_store(store_name)

if not requests_data:
    st.info("No return requests found for this store.")
    st.stop()

# --- Display Requests ---
st.markdown("### 🧾 Return Requests")
for i, req in enumerate(requests_data):
    with st.expander(f"📦 Order ID: {req['order_id']} • Status: {req['status']}"):
        st.write(f"**Reason:** {req['reason']}")
        st.write(f"**Date:** {req['timestamp']}")
        col1, col2 = st.columns([2, 1])
        with col1:
            new_status = st.selectbox(
                "Update Status",
                ["Pending", "Approved", "Rejected"],
                index=["Pending", "Approved", "Rejected"].index(req["status"]),
                key=f"status_{i}"
            )
        with col2:
            if st.button("💾 Save Status", key=f"save_{i}"):
                # Placeholder: status update logic using PATCH
                st.success(f"✅ Status updated to {new_status} for Order ID {req['order_id']}")

st.markdown("---")
st.caption("Returns SaaS • Role-Based Seller Dashboard + Onboarding • v3.1 ✨")
