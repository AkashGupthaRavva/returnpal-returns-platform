# utils/evaluator.py
import requests
from datetime import datetime

API_KEY = "AIzaSyBaMcUWcLWfyYwIYXRmaeZhBKZCK-rJHSo"
PROJECT_ID = "returnssaas"
BASE_URL = f"https://firestore.googleapis.com/v1/projects/{PROJECT_ID}/databases/(default)/documents"

def evaluate_return_request(store_name, submitted_date, reason, is_used=False, product_tags=""):
    doc_id = store_name.strip().lower().replace(" ", "_")
    rules_url = f"{BASE_URL}/return_policies/{doc_id}?key={API_KEY}"

    try:
        res = requests.get(rules_url)
        if res.status_code != 200:
            print("❌ Failed to fetch return rules.")
            return "Pending"

        rules = res.json().get("fields", {})
        return_window_days = int(rules.get("return_days", {}).get("integerValue", 14))
        non_returnable_tags = rules.get("non_returnable_tags", {}).get("stringValue", "").split(",")
        accept_used = rules.get("accept_used", {}).get("booleanValue", False)
        auto_approve_reasons = rules.get("auto_approve_reasons", {}).get("stringValue", "").split(",")

        # ⏳ Check return window
        days_diff = (datetime.now() - submitted_date).days
        if days_diff > return_window_days:
            return "Rejected"

        # 🚫 Check for restricted tags
        product_tags_list = [tag.strip().lower() for tag in product_tags.split(",")]
        forbidden_tags = [tag.strip().lower() for tag in non_returnable_tags]
        if any(tag in forbidden_tags for tag in product_tags_list):
            return "Rejected"

        # ♻️ Check if used items are allowed
        if is_used and not accept_used:
            return "Rejected"

        # ⚙️ Check if reason is in auto-approve list
        normalized_reason = reason.strip().lower()
        approved_reasons = [r.strip().lower() for r in auto_approve_reasons]
        if normalized_reason in approved_reasons:
            return "Approved"

        return "Pending"

    except Exception as e:
        print(f"Evaluator error: {e}")
        return "Pending"
